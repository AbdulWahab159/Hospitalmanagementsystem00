Hospital Management System - Four SQLite Database Copies

Contains four independent SQLite database files, each exactly 80,000,000 bytes (80 MB decimal).
Each has the same hospital schema and small demo dataset:
patients, doctors, appointments, medical_records, medicines, bills, bill_items, users, payments.

Note: The files are padded to the requested size; padding is not actual hospital data.
These are four copies, not four different repositories or production datasets.
The demo users/password hash is a placeholder and is not a usable login credential.
Your Flutter app must be wired to SQLite to read/write these files; simply placing them
in a ZIP does not automatically connect them to the app.
