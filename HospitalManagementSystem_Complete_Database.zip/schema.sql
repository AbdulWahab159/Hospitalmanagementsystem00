
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS patients (
 id INTEGER PRIMARY KEY,
 name TEXT NOT NULL,
 age INTEGER NOT NULL CHECK(age >= 0),
 gender TEXT NOT NULL,
 phone TEXT,
 address TEXT,
 blood_group TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS doctors (
 id INTEGER PRIMARY KEY,
 name TEXT NOT NULL,
 specialization TEXT NOT NULL,
 phone TEXT,
 email TEXT UNIQUE,
 availability TEXT,
 consultation_fee REAL NOT NULL DEFAULT 0 CHECK(consultation_fee >= 0),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS appointments (
 id INTEGER PRIMARY KEY,
 patient_id INTEGER NOT NULL,
 doctor_id INTEGER NOT NULL,
 appointment_date TEXT NOT NULL,
 appointment_time TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'Scheduled' CHECK(status IN ('Scheduled','Confirmed','Completed','Cancelled','No-show')),
 notes TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
 FOREIGN KEY(doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS medical_records (
 id INTEGER PRIMARY KEY,
 patient_id INTEGER NOT NULL,
 doctor_id INTEGER NOT NULL,
 diagnosis TEXT NOT NULL,
 treatment TEXT,
 record_date TEXT NOT NULL,
 notes TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE,
 FOREIGN KEY(doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS medicines (
 id INTEGER PRIMARY KEY,
 name TEXT NOT NULL,
 category TEXT,
 quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0),
 unit_price REAL NOT NULL DEFAULT 0 CHECK(unit_price >= 0),
 expiry_date TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bills (
 id INTEGER PRIMARY KEY,
 patient_id INTEGER NOT NULL,
 description TEXT NOT NULL,
 amount REAL NOT NULL CHECK(amount >= 0),
 bill_date TEXT NOT NULL,
 payment_status TEXT NOT NULL DEFAULT 'Pending' CHECK(payment_status IN ('Pending','Paid','Partially Paid','Cancelled')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS bill_items (
 id INTEGER PRIMARY KEY,
 bill_id INTEGER NOT NULL,
 item_description TEXT NOT NULL,
 quantity INTEGER NOT NULL DEFAULT 1 CHECK(quantity > 0),
 unit_price REAL NOT NULL CHECK(unit_price >= 0),
 FOREIGN KEY(bill_id) REFERENCES bills(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY,
 username TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('Admin','Doctor','Receptionist')),
 doctor_id INTEGER,
 is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(doctor_id) REFERENCES doctors(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS payments (
 id INTEGER PRIMARY KEY,
 bill_id INTEGER NOT NULL,
 amount REAL NOT NULL CHECK(amount > 0),
 payment_method TEXT NOT NULL DEFAULT 'Cash',
 payment_date TEXT NOT NULL,
 reference_no TEXT,
 FOREIGN KEY(bill_id) REFERENCES bills(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_patient ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_records_patient ON medical_records(patient_id);
CREATE INDEX IF NOT EXISTS idx_bills_patient ON bills(patient_id);
