
INSERT INTO patients(id,name,age,gender,phone,address,blood_group) VALUES
(1,'Ali Ahmed',28,'Male','03001234567','Islamabad','O+'),
(2,'Sara Khan',34,'Female','03111234567','Rawalpindi','A+');
INSERT INTO doctors(id,name,specialization,phone,email,availability,consultation_fee) VALUES
(3,'Dr. Ahmed Raza','Cardiologist','03009876543','ahmed@hospital.com','Mon-Fri',1500),
(4,'Dr. Hina Malik','Dermatologist','03119876543','hina@hospital.com','Tue-Sat',1200);
INSERT INTO appointments(id,patient_id,doctor_id,appointment_date,appointment_time,status,notes)
VALUES(5,1,3,'2026-11-28','10:30 AM','Confirmed','Routine checkup');
INSERT INTO medical_records(id,patient_id,doctor_id,diagnosis,treatment,record_date)
VALUES(6,1,3,'General checkup','Follow-up after one week','2026-11-20');
INSERT INTO medicines(id,name,category,quantity,unit_price,expiry_date) VALUES
(7,'Paracetamol','Tablet',100,25,'2027-06-30'),
(8,'Vitamin C','Supplement',50,40,'2027-03-31');
INSERT INTO bills(id,patient_id,description,amount,bill_date,payment_status)
VALUES(9,1,'Consultation',1500,'2026-11-20','Paid');
INSERT INTO payments(id,bill_id,amount,payment_method,payment_date,reference_no)
VALUES(1,9,1500,'Cash','2026-11-20','DEMO-PAY-001');
