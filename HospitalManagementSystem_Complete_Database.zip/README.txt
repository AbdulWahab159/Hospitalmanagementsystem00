Hospital Management System - Complete SQLite Database

Files:
- hospital_management.db : ready-to-open SQLite database with tables and sample records
- schema.sql : complete database schema, constraints, foreign keys, and indexes
- sample_data.sql : sample data matching the demo records in the supplied Flutter project
- README.txt : setup and usage notes

Tables:
patients, doctors, appointments, medical_records, medicines, bills, bill_items,
users, payments.

Important:
This is a standalone SQLite database. The supplied Flutter project's repository
was originally in-memory. To make the running app read/write this database, its
repository must be integrated with SQLite (for example sqflite). This database
file alone does not automatically connect the app.
Sample records are demo data only. No real patient information is included.
